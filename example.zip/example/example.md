
# 介绍
```
1. test：主项目    l_antd：打包文件

2. l_antd 通过 npm link 挂载全局，
   test通过 npm link l_antd  使用包文件

3. start启动test项目，只有一个app主文件，引入l_antd报错   

```