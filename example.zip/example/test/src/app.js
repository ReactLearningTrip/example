import React from 'react';
import ReactDOM from 'react-dom';
import {Test} from 'l_antd';

class ButtonT extends React.Component{
  render(){
    return <div>
      <p>111</p>
      <Test/>
    </div>
  }
}

ReactDOM.render(<ButtonT />, document.getElementById('testContent'));


