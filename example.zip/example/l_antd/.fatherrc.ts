export default {
  esm: 'babel',
  cjs: {
    type: 'babel',
    lazy: true,
  },
  extractCSS: true,
  lessInBabelMode: true,
  autoprefixer: {
    browsers: ['ie>8', 'Safari >= 6'],
  },
};
