---
title: Layout 布局
toc: menus
---

# Layout

代码演示

<code src="../../demo/layout" title="基本" desc="基本布局"  />

API:

| 属性      | 说明           | 类型          | 默认值 |
| --------- | -------------- | ------------- | ------ |
| className | 容器 className | string        | -      |
| style     | 指定样式       | CSSProperties | -      |
