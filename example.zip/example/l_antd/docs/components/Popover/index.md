---
title: Popover 气泡
toc: menus
---

# Popover

代码演示

<code src="../../demo/popover" title="基本" desc="气泡" />

API:

| 属性         | 说明             | 类型              | 默认值                            |
| ------------ | ---------------- | ----------------- | --------------------------------- |
| leftContent  | 导航左边内容     | any               | '返回'                            |
| rightContent | 导航右边内容     | any               | 无                                |
| onLeftClick  | 导航左边点击回调 | (e: Object): void | <code>() => history.back()</code> |
