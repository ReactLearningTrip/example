import React from 'react';

import { Layout } from 'l_antd';

import './index.less';

export default () => (
  <div className="components-layout">
    <Layout>
      <Layout.Header>Header</Layout.Header>
      <Layout.Content>Content</Layout.Content>
      <Layout.Footer>Footer</Layout.Footer>
    </Layout>
  </div>
);
