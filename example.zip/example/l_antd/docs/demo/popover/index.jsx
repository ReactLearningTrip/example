import React from 'react';

import { Popover } from 'l_antd';

const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);

export default () => (
  <Popover content={content} title="Title" trigger="click">
    <a>测试</a>
  </Popover>
);
