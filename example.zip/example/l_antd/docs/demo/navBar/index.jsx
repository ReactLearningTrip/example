import React from 'react';

import { NavBar } from 'l_antd';

import './index.less';

export default () => (
  <div className="components-navBar">
    <NavBar leftContent="返回" rightContent="删除">
      标题
    </NavBar>
  </div>
);
