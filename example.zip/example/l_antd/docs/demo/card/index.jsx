import React from 'react';

import { Card ,formCommon,Test} from 'l_antd';

export default () => <div>{JSON.stringify(formCommon)}<Card></Card><Test/></div>;
