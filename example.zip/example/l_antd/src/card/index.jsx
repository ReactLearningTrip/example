import React from 'react';
import classnames from 'classnames';

import './style/css';

const Card = ({
  className,
  title,
  cover,
  extra,
  bordered,
  children,
  ...props
}) => (
  <div
    className={classnames('card', {
      'card-bordered': bordered,
    })}
    {...props}
  >
    {title && (
      <div className="card-head">
        <div className="card-head-wrapper">
          <div className="card-head-title">{title}</div>
          {extra && <div className="card-extra">{extra}</div>}
        </div>
      </div>
    )}
    {cover && (
      <div className="card-cover">
        <img alt="example" src={cover} />
      </div>
    )}
    <div className="card-body">{children}</div>
  </div>
);

// 扩展 body
const Meta = ({ title, description }) => (
  <div class="card-meta">
    <div class="card-meta-detail">
      <div class="card-meta-description">{description}</div>
      <div class="card-meta-title">{title}</div>
    </div>
  </div>
);

Card.Meta = Meta;

export default Card;
