import { ApplyPluginsType } from 'D:/project/RayCloud/l_antd/node_modules/@umijs/runtime';
import { plugin } from './plugin';

const routes = [
  {
    "path": "/_demos/index",
    "component": require('D:/project/RayCloud/l_antd/docs/demo/card/index.jsx').default,
    "exact": true
  },
  {
    "path": "/_demos/index-1",
    "component": require('D:/project/RayCloud/l_antd/docs/demo/layout/index.jsx').default,
    "exact": true
  },
  {
    "path": "/_demos/index-2",
    "component": require('D:/project/RayCloud/l_antd/docs/demo/navBar/index.jsx').default,
    "exact": true
  },
  {
    "path": "/_demos/index-3",
    "component": require('D:/project/RayCloud/l_antd/docs/demo/popover/index.jsx').default,
    "exact": true
  },
  {
    "path": "/",
    "component": (props) => require('react').createElement(require('D:/project/RayCloud/l_antd/node_modules/@umijs/preset-dumi/lib/themes/default/layout.js').default, {
      ...{"menus":{"*":{"*":[{"path":"/","title":"使用","meta":{}},{"title":"Components","path":"/components","meta":{},"children":[{"path":"/components/card","title":"Card 卡片","meta":{}},{"path":"/components/layout","title":"Layout 布局","meta":{}},{"path":"/components/nav-bar","title":"NavBar 导航","meta":{}},{"path":"/components/popover","title":"Popover 气泡","meta":{}}]}]}},"locales":[],"navs":{},"title":"Library Name","mode":"doc"},
      ...props,
    }),
    "routes": [
      {
        "path": "/",
        "component": require('D:/project/RayCloud/l_antd/docs/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/index.md",
          "updatedTime": 1589956455000,
          "slugs": [
            {
              "depth": 2,
              "value": "使用",
              "heading": "使用"
            }
          ],
          "title": "使用"
        },
        "title": "使用"
      },
      {
        "path": "/components/card",
        "component": require('D:/project/RayCloud/l_antd/docs/components/Card/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/components/Card/index.md",
          "updatedTime": 1589956455000,
          "title": "Card 卡片",
          "toc": " menus",
          "slugs": [
            {
              "depth": 1,
              "value": "Card",
              "heading": "card"
            }
          ],
          "group": {
            "path": "/components",
            "title": "Components"
          }
        },
        "title": "Card 卡片"
      },
      {
        "path": "/components/layout",
        "component": require('D:/project/RayCloud/l_antd/docs/components/Layout/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/components/Layout/index.md",
          "updatedTime": 1589956455000,
          "title": "Layout 布局",
          "toc": "menus",
          "slugs": [
            {
              "depth": 1,
              "value": "Layout",
              "heading": "layout"
            }
          ],
          "group": {
            "path": "/components",
            "title": "Components"
          }
        },
        "title": "Layout 布局"
      },
      {
        "path": "/components/nav-bar",
        "component": require('D:/project/RayCloud/l_antd/docs/components/NavBar/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/components/NavBar/index.md",
          "updatedTime": 1589956455000,
          "title": "NavBar 导航",
          "toc": "menus",
          "slugs": [
            {
              "depth": 1,
              "value": "NavBar",
              "heading": "navbar"
            }
          ],
          "group": {
            "path": "/components",
            "title": "Components"
          }
        },
        "title": "NavBar 导航"
      },
      {
        "path": "/components/popover",
        "component": require('D:/project/RayCloud/l_antd/docs/components/Popover/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/components/Popover/index.md",
          "updatedTime": 1589956455000,
          "title": "Popover 气泡",
          "toc": "menus",
          "slugs": [
            {
              "depth": 1,
              "value": "Popover",
              "heading": "popover"
            }
          ],
          "group": {
            "path": "/components",
            "title": "Components"
          }
        },
        "title": "Popover 气泡"
      },
      {
        "path": "/components",
        "meta": {},
        "exact": true,
        "redirect": "/components/card"
      }
    ],
    "title": "Library Name"
  }
];

// allow user to extend routes
plugin.applyPlugins({
  key: 'patchRoutes',
  type: ApplyPluginsType.event,
  args: { routes },
});

export { routes };
