import {message} from 'antd';
import $ from 'jquery';
import createHistory from 'history/createBrowserHistory';
const history = createHistory();



function urlParse(paramsString){
    let search=window.location.search.slice(1);
    paramsString=paramsString||search;
    let obj= {};
    let reg = /([^?&=]+)=([^?&=]*)/g;
    paramsString.replace(reg, function (rs, params1, params2) {
        let name = decodeURIComponent(params1);
        let val = decodeURIComponent(params2);
        val = String(val);
        obj[name] = val;
        return rs;
    });
    return obj;
}
//scrollTo(0,0)
function  tableScrollToTopFn(id){
    let position=$(id).find('.ant-table-body');
    let newtop;
    let timer=setInterval(function(){
        newtop = position.scrollTop();
        if(position.scrollTop()<=0){
          clearInterval(timer);
        }else{
            let a =position.scrollTop(newtop -100);
        }
      },10);
}


function form_error_fn(form,message_data){
    // let err={}
    message.error(message_data,5)
    // message=message|| {};
    // let values=form.getFieldsValue();
    // for(let key of message){
    //     err[key]={
    //         value:values[key],
    //         errors:[new Error(message[key])]
    //     }
    // }
    // form.setFields(err)
}
function get_scroll_obj(...arr){
    let rootID=arr[0].rootID||'';
    let noCommonList=arr[0].noCommonList;
    let length=arr[0].length;
    let height=arr[0].height || 54;
    let always_scroll=arr[0].always_scroll || false;
    let always_scroll_x=arr[0].always_scroll_x || false;
    let columns=arr[0].columns || [];
    columns=columns.slice(0)
    let table_body_height=length*height;
    let class_name=arr.slice(1);
    let all_height=$('body').outerHeight(true);
    let class_name_height=0;
    for(let i=0;i<class_name.length;i++){
        let class_nameI=class_name[i];
        if((typeof class_nameI)=='number'){
            class_name_height+=class_nameI;
        }else{
            if((class_nameI=='.l_header') && !$('#'+rootID).find(class_nameI).outerHeight(true)){
                class_name_height+=80;
            }else if((class_nameI=='.ant-tabs-bar') && !$('#'+rootID).find(class_nameI).outerHeight(true)){
                class_name_height+=56;
            }else if((class_nameI=='.ant-table-thead') && !$('#'+rootID).find(class_nameI).outerHeight(true)){
                class_name_height+=54;
            }else if((class_nameI=='.l_common_search_height') && !$('#'+rootID).find(class_nameI).outerHeight(true)){
                class_name_height+=64;
            }else if((class_nameI=='.l_pagination') && !$('#'+rootID).find(class_nameI).outerHeight(true)){
                class_name_height+=64;
            }else{
                class_name_height+=$('#'+rootID).find(class_nameI).outerHeight(true) || 0;
            }
        }
    }
    
    let obj={};//always_scroll_x
    
    if(always_scroll){
        if(always_scroll==true){
            obj={
                scroll:{'y':all_height-class_name_height}
            }
        }else{
            obj={
                scroll:{'y':always_scroll}
            }
        }
    }else if((class_name_height+table_body_height)>all_height){
        obj={
            scroll:{'y':all_height-class_name_height}
        }
    }
    
    obj['styleCommonList']=noCommonList?{}:{'height':(all_height-class_name_height+55)+'px'}
    obj['classCommonList']=noCommonList?'':'lClassCommonList'
    let always_scroll_x_width=0;
    if(always_scroll_x){
       //1123678
        let tableBodyWith=$('.l_router_div_right');
        tableBodyWith=tableBodyWith?(tableBodyWith.outerWidth(true)-48):0;
       
        for(let i=0;i<columns.length;i++){
            if(!!columns[i].width){
               if(typeof columns[i].width =='number'){
                   always_scroll_x_width+=columns[i].width;
               }else if(columns[i].width.indexOf('px')>=0){
                   always_scroll_x_width+=parseInt(columns[i].width.slice(0,-2));
               } 
            }
        }
        
        let columnsNew=columns;
        columnsNew=columnsNew.map((ele,index)=>{
            let columnsWidth=ele.width;
            if((typeof columnsWidth =='string')&&(columnsWidth.indexOf('px')>=0)){
                columnsWidth=columnsWidth.slice(0,-2)
                columnsWidth=parseFloat(columnsWidth);
            } 
            return {
                ...ele,
                fixed:false,
                width:(columnsWidth/always_scroll_x_width)*tableBodyWith
            }
            
        })
        if(tableBodyWith>always_scroll_x_width){
            obj={
                ...obj,
                columns:columnsNew
            }
        }else{
            obj={
                ...obj,
                scroll:{
                    ...obj.scroll,
                    x:always_scroll_x_width
                },
                columns
            }
        }
    }
    return obj;
}
function refresh_fn(that){
    
    let refresh_status=Math.random();
    let timeout=null;
    window.top.addEventListener("resize",()=>{
        if(!timeout){
            timeout=setTimeout(() => {
                that.setState({
                    refresh_status
                })
            }, 300);
        }else{
            clearTimeout(timeout);
            timeout=null;
            timeout=setTimeout(() => {
                that.setState({
                    refresh_status
                })
            }, 300);
        }
        
    })
}
function jumpHideRouteFn(params){
    
    let left_menu=params.left_menu;
    let router_url=params.router_url;
    let edit_menu_fn=params.edit_menu_fn;
    let show_tabs=left_menu.show_tabs;
    let all_tabs=left_menu.all_tabs;
    let all_tabs_obj={};
    for(let i=0;i<all_tabs.length;i++){
       all_tabs_obj[all_tabs[i].path]=all_tabs[i]
    }
    if(!all_tabs_obj[router_url] || !all_tabs_obj[router_url].id){
        message.warning('您没有访问权限，请联系管理员。')
        return;
    }
    let activeKey=all_tabs_obj[router_url].id;
    console.log('router_url==跳转页面')
    console.log(router_url)
    history.push(router_url)
    if(!show_tabs.includes(activeKey)){
        show_tabs.push(activeKey);
    }
    edit_menu_fn({
      activeKey,
      show_tabs
   });
}



class global_locales{
    constructor(){
        this.name = 'umi_locale';
    }
    get(){
        let locale=window.localStorage.getItem(this.name)||'zh-CN';
        return locale;
    }
}
let global_locales_fn=new global_locales();

export {urlParse,tableScrollToTopFn,form_error_fn,get_scroll_obj,refresh_fn,jumpHideRouteFn,global_locales_fn}