import React from 'react';

import './style/css';

const NavBar = ({
  leftContent = '返回',
  rightContent,
  children,
  onLeftClick = () => history.back(),
}) => (
  <div class="am-navbar">
    <div class="am-navbar-left" role="button" onClick={onLeftClick}>
      {leftContent}
    </div>
    <div class="am-navbar-title">{children}</div>
    <div class="am-navbar-right">{rightContent}</div>
  </div>
);

export default NavBar;
