import React from 'react';
import {Table} from 'antd';


class Test extends React.Component{
     render(){
         return <Table/>
     }
}

export default Test;
