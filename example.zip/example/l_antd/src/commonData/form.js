const formCommon={
    dateFormatList:['YYYY-MM-DD HH:mm:ss', 'YYYY-MM-DD HH:mm:ss'],
    dateFormat:'YYYY-MM-DD HH:mm:ss',
    dateFormatMin:'YYYY-MM-DD HH:mm',
    dateFormatDay:'YYYY-MM-DD',
    timeFormat:'HH:mm:ss',
}
export default formCommon;
