import React from 'react';

import classnames from 'classnames';

import './style/css';

const generator = type => ({ className, ...props }) => (
  <div {...props} className={classnames(type, className)} />
);

const Layout = generator('ant-layout');

Layout.Header = generator('ant-layout-header');
Layout.Content = generator('ant-layout-content');
Layout.Footer = generator('ant-layout-footer');
export default Layout;
